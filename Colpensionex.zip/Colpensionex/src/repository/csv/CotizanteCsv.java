/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository.csv;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import modelo.Cotizante;
import repositorio.ICotizante;

/**
 *
 * @author manuc
 */
public class CotizanteCsv implements ICotizante{

       private Map<String, Cotizante> cotizantes = new HashMap<>();

    @Override
    public void leerDesdeCsv(String filePath) throws IOException {
        cotizantes.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String linea;

            br.readLine();

            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");

                String id = datos[0].trim();
                String nombre = datos[1].trim();
                String tipo = datos[2].trim();

                Cotizante cotizante = new Cotizante(id, nombre, tipo);

                cotizantes.put(id, cotizante);
            }
        }
    }
    
    public Map<String, Cotizante> getCotizantes() {
        return cotizantes;
    }

    @Override
    public void escribirEnCsv(String filePathActivos, String filePathEmbargados, String filePathPendientes) throws IOException {
        
        
    }
}
