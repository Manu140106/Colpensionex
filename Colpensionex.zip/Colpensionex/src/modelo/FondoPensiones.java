/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author manuc
 */
public class FondoPensiones {
    
     private String idFondo;
    private String nombre;

    public FondoPensiones(String idFondo, String nombre) {
        this.idFondo = idFondo;
        this.nombre = nombre;
    }

    public String getIdFondo() {
        return idFondo;
    }

    public void setIdFondo(String idFondo) {
        this.idFondo = idFondo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "FondoPensiones{" + "idFondo='" + idFondo + '\'' + ", nombre='" + nombre + '\'' + '}';
    }
}
