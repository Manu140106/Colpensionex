/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author manuc
 */
public class Embargo {
   
    private String idEmbargo;
    private String motivo;
    private LocalDate fecha;

    public Embargo(String idEmbargo, String motivo, LocalDate fecha) {
        this.idEmbargo = idEmbargo;
        this.motivo = motivo;
        this.fecha = fecha;
    }

    public String getIdEmbargo() {
        return idEmbargo;
    }

    public void setIdEmbargo(String idEmbargo) {
        this.idEmbargo = idEmbargo;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Embargo{" + "idEmbargo='" + idEmbargo + '\'' + ", motivo='" + motivo + '\'' + ", fecha=" + fecha + '}';
    }
}
