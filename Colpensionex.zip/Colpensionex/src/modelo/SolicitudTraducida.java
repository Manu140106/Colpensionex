/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author manuc
 */
public class SolicitudTraducida {
    
    private String idSolicitud;
    private Cotizante cotizante;
    private String estado;

    public SolicitudTraducida(String idSolicitud, Cotizante cotizante, String estado) {
        this.idSolicitud = idSolicitud;
        this.cotizante = cotizante;
        this.estado = estado;
    }

    public String getIdSolicitud() {
        return idSolicitud;
    }

    public void setIdSolicitud(String idSolicitud) {
        this.idSolicitud = idSolicitud;
    }

    public Cotizante getCotizante() {
        return cotizante;
    }

    public void setCotizante(Cotizante cotizante) {
        this.cotizante = cotizante;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "SolicitudTraducida{" + "idSolicitud='" + idSolicitud + '\'' + ", cotizante=" + cotizante + ", estado='" + estado + '\'' + '}';
    }
}
