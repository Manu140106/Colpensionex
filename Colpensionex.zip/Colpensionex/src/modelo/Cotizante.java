/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author manuc
 */
public class Cotizante {
    
    private String nombre;
    private String apellido;
    private int edad;
    private boolean embargado;

    public Cotizante(String nombre, String apellido, int edad, boolean embargado) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.embargado = embargado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public boolean isEmbargado() {
        return embargado;
    }

    public void setEmbargado(boolean embargado) {
        this.embargado = embargado;
    }
    
    
}
