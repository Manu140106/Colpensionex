/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Date;

/**
 *
 * @author manuc
 */
public class SolicitudTraslado {

    private String identificacion;
    private Cotizante cotizante;       
    private Date fechaSolicitud;
    private Estado estado;            
    private String motivoRechazo;     


    public enum Estado {
        PENDIENTE,
        APROBADO,
        RECHAZADO
    }

    public SolicitudTraslado(String identificacion, Cotizante cotizante, Date fechaSolicitud) {
        this.identificacion = identificacion;
        this.cotizante = cotizante;
        this.fechaSolicitud = fechaSolicitud;
        this.estado = Estado.PENDIENTE; 
        this.motivoRechazo = null;     
    }


    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public Cotizante getCotizante() {
        return cotizante;
    }

    public void setCotizante(Cotizante cotizante) {
        this.cotizante = cotizante;
    }

    public Date getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Date fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public Estado getEstado() {
        return estado;
    }

    public String getMotivoRechazo() {
        return motivoRechazo;
    }

    public void aprobarSolicitud() {
        if (this.estado == Estado.PENDIENTE) {
            this.estado = Estado.APROBADO;
            this.motivoRechazo = null;
        }
    }

    public void rechazarSolicitud(String motivo) {
        if (this.estado == Estado.PENDIENTE) {
            this.estado = Estado.RECHAZADO;
            this.motivoRechazo = motivo;
        }
    }

    @Override
    public String toString() {
        return "SolicitudTraslado{" +
                "identificacion='" + identificacion + '\'' +
                ", cotizante=" + cotizante +
                ", fechaSolicitud=" + fechaSolicitud +
                ", estado=" + estado +
                ", motivoRechazo='" + motivoRechazo + '\'' +
                '}';
    }
}

