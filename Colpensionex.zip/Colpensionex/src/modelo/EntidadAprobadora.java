/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author manuc
 */
public class EntidadAprobadora {
    
    private String idEntidad;
    private String nombre;

    public EntidadAprobadora(String idEntidad, String nombre) {
        this.idEntidad = idEntidad;
        this.nombre = nombre;
    }

    public String getIdEntidad() {
        return idEntidad;
    }

    public void setIdEntidad(String idEntidad) {
        this.idEntidad = idEntidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "EntidadAprobadora{" + "idEntidad='" + idEntidad + '\'' + ", nombre='" + nombre + '\'' + '}';
    }
}
