/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author manuc
 */
public class PaquetesTraslados {
    
    private String idPaquete;
    private List<Cotizante> cotizantes;

    public PaquetesTraslados(String idPaquete) {
        this.idPaquete = idPaquete;
        this.cotizantes = new ArrayList<>();
    }

    public String getIdPaquete() {
        return idPaquete;
    }

    public void setIdPaquete(String idPaquete) {
        this.idPaquete = idPaquete;
    }

    public List<Cotizante> getCotizantes() {
        return cotizantes;
    }

    public void agregarCotizante(Cotizante cotizante) {
        cotizantes.add(cotizante);
    }

    @Override
    public String toString() {
        return "PaquetesTraslados{" + "idPaquete='" + idPaquete + '\'' + ", cotizantes=" + cotizantes + '}';
    }
}
