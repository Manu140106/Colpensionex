/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Date;

/**
 *
 * @author manuc
 */
public class SolicitudEmbargo {
    
     private String identificacion;
    private Cotizante cotizante;             
    private EntidadEmbargo entidadSolicitante; 
    private Date fechaSolicitud;
    private Estado estado;                  

    public enum Estado {
        ACTIVO,
        INACTIVO
    }

    public SolicitudEmbargo(String identificacion, Cotizante cotizante, EntidadEmbargo entidadSolicitante, Date fechaSolicitud) {
        this.identificacion = identificacion;
        this.cotizante = cotizante;
        this.entidadSolicitante = entidadSolicitante;
        this.fechaSolicitud = fechaSolicitud;
        this.estado = Estado.ACTIVO; 
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public Cotizante getCotizante() {
        return cotizante;
    }

    public void setCotizante(Cotizante cotizante) {
        this.cotizante = cotizante;
    }

    public EntidadEmbargo getEntidadSolicitante() {
        return entidadSolicitante;
    }

    public void setEntidadSolicitante(EntidadEmbargo entidadSolicitante) {
        this.entidadSolicitante = entidadSolicitante;
    }

    public Date getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Date fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public Estado getEstado() {
        return estado;
    }

    public void activarSolicitud() {
        this.estado = Estado.ACTIVO;
    }

    public void inactivarSolicitud() {
        this.estado = Estado.INACTIVO;
    }

    @Override
    public String toString() {
        return "SolicitudEmbargo{" +
                "identificacion='" + identificacion + '\'' +
                ", cotizante=" + cotizante +
                ", entidadSolicitante=" + entidadSolicitante +
                ", fechaSolicitud=" + fechaSolicitud +
                ", estado=" + estado +
                '}';
    }
}
